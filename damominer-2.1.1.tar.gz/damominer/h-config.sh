#!/usr/bin/env bash

mkfile_from_symlink $CUSTOM_CONFIG_FILENAME

#echo "CUSTOM_ALGO:        $CUSTOM_ALGO"
#echo "CUSTOM_URL:         $CUSTOM_URL"
#echo "CUSTOM_TLS:         $CUSTOM_TLS"
#echo "CUSTOM_TEMPLATE:    $CUSTOM_TEMPLATE"
#echo "CUSTOM_WORKER:      $CUSTOM_WORKER"
#echo "CUSTOM_PASS:        $CUSTOM_PASS"
#echo "CUSTOM_USER_CONFIG: $CUSTOM_USER_CONFIG"

local conf=""

[[ -n $CUSTOM_USER_CONFIG ]] && conf+=" ${CUSTOM_USER_CONFIG}"

echo "$conf" > $CUSTOM_CONFIG_FILENAME

