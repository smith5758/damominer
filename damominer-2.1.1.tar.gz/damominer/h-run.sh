#!/usr/bin/env bash

export GPU_MAX_ALLOC_PERCENT=100
export GPU_SINGLE_ALLOC_PERCENT=100
export GPU_MAX_HEAP_SIZE=100
export GPU_USE_SYNC_OBJECTS=1

[[ `ps aux | grep "./damominer  --address" | grep -v grep | wc -l` != 0 ]] &&
  echo -e "${RED}$CUSTOM_NAME miner is already running${NOCOLOR}" &&
  exit 1

[[ -f ${CUSTOM_LOG_BASENAME}_head.log ]] && rm "${CUSTOM_LOG_BASENAME}_head.log"

. h-manifest.conf
value=$(<damominer.conf)
chmod +x  ./damominer
WATCHDOG=""
[[ -e watchdog.sh ]] && WATCHDOG="--watchdog_script"
./damominer  ${value}  2>&1 | tee --append ${CUSTOM_LOG_BASENAME}.log
